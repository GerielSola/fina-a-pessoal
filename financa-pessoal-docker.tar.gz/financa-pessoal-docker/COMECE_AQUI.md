# 🚀 Comece Aqui - Controle Financeiro Pessoal

Guia de 5 minutos para colocar a aplicação rodando.

## ⚡ Instalação Rápida

### Passo 1: Ir para o diretório

```bash
cd /root/financa-pessoal-docker
```

### Passo 2: Executar deploy

```bash
./deploy-servidor.sh
```

### Passo 3: Aguardar inicialização

O script vai:
- ✅ Verificar Docker e Docker Compose
- ✅ Verificar N8N e rede Docker
- ✅ Iniciar MySQL, Backend e Frontend
- ✅ Mostrar URLs de acesso

### Passo 4: Acessar

Abra no navegador:
- **Frontend**: http://localhost:5173
- **API**: http://localhost:3000

## 🧪 Testar a API

### Listar Categorias

```bash
curl http://localhost:3000/api/categorias
```

Você deve ver:
```json
[
  {"id": 1, "nome": "Salário", "tipo": "receita"},
  {"id": 2, "nome": "Freelance", "tipo": "receita"},
  ...
]
```

### Criar uma Transação

```bash
curl -X POST http://localhost:3000/api/transacoes \
  -H "Content-Type: application/json" \
  -d '{
    "categoria_id": 1,
    "descricao": "Salário mensal",
    "valor": 3000,
    "tipo": "receita",
    "data_transacao": "2025-01-28",
    "status": "pago"
  }'
```

Você deve receber:
```json
{
  "id": 1,
  "categoria_id": 1,
  "descricao": "Salário mensal",
  "valor": 3000,
  "tipo": "receita",
  "data_transacao": "2025-01-28",
  "status": "pago"
}
```

## 📊 Verificar Status

```bash
docker-compose ps
```

Você deve ver:
```
NAME                    STATUS              PORTS
financa-mysql           Up 2 minutes        0.0.0.0:3307->3306/tcp
financa-backend         Up 2 minutes        0.0.0.0:3000->3000/tcp
financa-frontend        Up 2 minutes        0.0.0.0:5173->5173/tcp
```

## 🔗 Integração com N8N

### URL para N8N

Use esta URL nos workflows do N8N:

```
http://financa-backend:3000/api
```

### Exemplo Simples

1. Abra N8N (http://localhost:3333)
2. Crie novo workflow
3. Adicione nó **HTTP Request**
4. Configure:
   - **Method**: GET
   - **URL**: http://financa-backend:3000/api/categorias
5. Execute

## 🛠️ Comandos Úteis

### Ver Logs

```bash
# Todos os logs
docker-compose logs -f

# Apenas backend
docker-compose logs -f backend-financa

# Apenas MySQL
docker-compose logs -f mysql-financa
```

### Parar Aplicação

```bash
docker-compose stop
```

### Reiniciar Aplicação

```bash
docker-compose restart
```

### Remover Tudo (incluindo dados)

```bash
docker-compose down -v
```

## 📚 Documentação Completa

Depois de testar, leia:

1. **INSTALACAO_SERVIDOR.md** - Instalação detalhada
2. **N8N_INTEGRACAO.md** - Workflows com N8N
3. **README.md** - Documentação técnica

## ❌ Problemas?

### Erro: "Port already in use"

```bash
# Encontrar processo
lsof -i :3000

# Matar processo
kill -9 <PID>
```

### Erro: "MySQL connection refused"

```bash
# Reiniciar MySQL
docker-compose restart mysql-financa

# Aguardar 10 segundos
sleep 10

# Verificar logs
docker-compose logs mysql-financa
```

### Erro: "Cannot reach financa-backend"

```bash
# Verificar se containers estão rodando
docker-compose ps

# Verificar rede
docker network ls | grep n8n
```

## 🎯 Próximos Passos

1. ✅ Testar endpoints da API
2. ⏭ Criar workflows no N8N
3. ⏭ Importar dados da planilha Excel
4. ⏭ Desenvolver interface do frontend
5. ⏭ Configurar backups automáticos

## 📞 Precisa de Ajuda?

```bash
# Ver todos os logs
docker-compose logs

# Acessar MySQL
docker-compose exec mysql-financa mysql -u financa_user -p financa_pessoal

# Acessar Backend
docker-compose exec backend-financa sh
```

---

**Pronto!** 🎉

Sua aplicação está rodando. Comece testando a API e depois explore os workflows do N8N.

Para mais informações, leia os arquivos `.md` na pasta do projeto.
