-- Criação das tabelas para o sistema de controle financeiro pessoal

USE financa_pessoal;

-- Tabela de categorias
CREATE TABLE IF NOT EXISTS categorias (
  id INT PRIMARY KEY AUTO_INCREMENT,
  nome VARCHAR(100) NOT NULL UNIQUE,
  tipo ENUM('receita', 'despesa') NOT NULL,
  descricao TEXT,
  ativa BOOLEAN DEFAULT TRUE,
  criada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de transações
CREATE TABLE IF NOT EXISTS transacoes (
  id INT PRIMARY KEY AUTO_INCREMENT,
  categoria_id INT NOT NULL,
  descricao VARCHAR(255) NOT NULL,
  valor DECIMAL(12, 2) NOT NULL,
  tipo ENUM('receita', 'despesa') NOT NULL,
  data_transacao DATE NOT NULL,
  data_pagamento DATE,
  status ENUM('pendente', 'pago', 'cancelado') DEFAULT 'pendente',
  notas TEXT,
  criada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (categoria_id) REFERENCES categorias(id) ON DELETE RESTRICT,
  INDEX idx_data (data_transacao),
  INDEX idx_tipo (tipo),
  INDEX idx_categoria (categoria_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de orçamentos
CREATE TABLE IF NOT EXISTS orcamentos (
  id INT PRIMARY KEY AUTO_INCREMENT,
  categoria_id INT NOT NULL,
  mes_ano DATE NOT NULL,
  valor_limite DECIMAL(12, 2) NOT NULL,
  alerta_percentual INT DEFAULT 80,
  ativo BOOLEAN DEFAULT TRUE,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (categoria_id) REFERENCES categorias(id) ON DELETE CASCADE,
  UNIQUE KEY unique_categoria_mes (categoria_id, mes_ano),
  INDEX idx_mes (mes_ano)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de contas/carteiras
CREATE TABLE IF NOT EXISTS contas (
  id INT PRIMARY KEY AUTO_INCREMENT,
  nome VARCHAR(100) NOT NULL,
  tipo ENUM('banco', 'cartao_credito', 'carteira', 'investimento') NOT NULL,
  saldo_inicial DECIMAL(12, 2) DEFAULT 0,
  saldo_atual DECIMAL(12, 2) DEFAULT 0,
  ativa BOOLEAN DEFAULT TRUE,
  criada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de transferências entre contas
CREATE TABLE IF NOT EXISTS transferencias (
  id INT PRIMARY KEY AUTO_INCREMENT,
  conta_origem_id INT NOT NULL,
  conta_destino_id INT NOT NULL,
  valor DECIMAL(12, 2) NOT NULL,
  data_transferencia DATE NOT NULL,
  descricao VARCHAR(255),
  criada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (conta_origem_id) REFERENCES contas(id) ON DELETE RESTRICT,
  FOREIGN KEY (conta_destino_id) REFERENCES contas(id) ON DELETE RESTRICT,
  INDEX idx_data (data_transferencia)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de metas financeiras
CREATE TABLE IF NOT EXISTS metas (
  id INT PRIMARY KEY AUTO_INCREMENT,
  nome VARCHAR(100) NOT NULL,
  descricao TEXT,
  valor_alvo DECIMAL(12, 2) NOT NULL,
  valor_atual DECIMAL(12, 2) DEFAULT 0,
  data_inicio DATE NOT NULL,
  data_alvo DATE NOT NULL,
  status ENUM('ativa', 'concluida', 'cancelada') DEFAULT 'ativa',
  criada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Inserir categorias padrão
INSERT INTO categorias (nome, tipo, descricao) VALUES
('Salário', 'receita', 'Renda principal'),
('Freelance', 'receita', 'Trabalhos pontuais'),
('Investimentos', 'receita', 'Rendimento de investimentos'),
('Outros', 'receita', 'Outras receitas'),
('Alimentação', 'despesa', 'Compras de alimentos e refeições'),
('Transporte', 'despesa', 'Combustível, passagens, estacionamento'),
('Moradia', 'despesa', 'Aluguel, condomínio, IPTU'),
('Utilidades', 'despesa', 'Água, luz, internet, telefone'),
('Saúde', 'despesa', 'Médicos, medicamentos, academia'),
('Educação', 'despesa', 'Cursos, livros, mensalidades'),
('Lazer', 'despesa', 'Cinema, viagens, diversão'),
('Compras', 'despesa', 'Roupas, eletrônicos, diversos'),
('Seguros', 'despesa', 'Seguro de vida, carro, etc'),
('Impostos', 'despesa', 'Impostos e taxas'),
('Outros', 'despesa', 'Outras despesas');

-- Inserir conta padrão
INSERT INTO contas (nome, tipo, saldo_inicial, saldo_atual) VALUES
('Conta Corrente', 'banco', 0, 0),
('Cartão de Crédito', 'cartao_credito', 0, 0),
('Carteira', 'carteira', 0, 0);
