# 💰 Controle Financeiro Pessoal - Docker

Aplicativo completo de controle financeiro pessoal com backend API e frontend web, containerizado com Docker e integrado com N8N.

## 🎯 Características

- ✅ **Backend Node.js/Express** - API REST robusta
- ✅ **Frontend React/Vite** - Interface moderna
- ✅ **MySQL 8.0** - Banco de dados confiável
- ✅ **Docker Compose** - Fácil deploy
- ✅ **Integração N8N** - Automações poderosas
- ✅ **Documentação Completa** - Guias passo a passo

## 🚀 Início Rápido

### 1. Instalar

```bash
cd /root/financa-pessoal-docker
./deploy-servidor.sh
```

### 2. Acessar

- **Frontend**: http://localhost:5173
- **API**: http://localhost:3000
- **Health**: http://localhost:3000/health

### 3. Testar

```bash
# Listar categorias
curl http://localhost:3000/api/categorias

# Criar transação
curl -X POST http://localhost:3000/api/transacoes \
  -H "Content-Type: application/json" \
  -d '{
    "categoria_id": 1,
    "descricao": "Salário",
    "valor": 3000,
    "tipo": "receita",
    "data_transacao": "2025-01-28",
    "status": "pago"
  }'
```

## 📋 Documentação

| Documento | Descrição |
|-----------|-----------|
| **INSTALACAO_SERVIDOR.md** | Guia de instalação no servidor |
| **N8N_INTEGRACAO.md** | Integração com N8N (workflows) |
| **QUICK_START.md** | Guia rápido (3 passos) |

## 🐳 Serviços

| Serviço | Porta | URL |
|---------|-------|-----|
| **Frontend** | 5173 | http://localhost:5173 |
| **Backend** | 3000 | http://localhost:3000 |
| **MySQL** | 3307 | localhost:3307 |

## 📊 Banco de Dados

### Tabelas

- **categorias** - Tipos de receita/despesa
- **transacoes** - Movimentações financeiras
- **orcamentos** - Limites de gastos
- **contas** - Contas bancárias
- **transferencias** - Movimentações entre contas
- **metas** - Objetivos financeiros

### Credenciais

```
Host:     localhost
Porta:    3307
Usuário:  financa_user
Senha:    financa_password_123
Database: financa_pessoal
```

## 📡 API Endpoints

### Categorias
```
GET    /api/categorias              - Listar
GET    /api/categorias/:id          - Obter
POST   /api/categorias              - Criar
PUT    /api/categorias/:id          - Atualizar
DELETE /api/categorias/:id          - Deletar
```

### Transações
```
GET    /api/transacoes              - Listar
GET    /api/transacoes/:id          - Obter
POST   /api/transacoes              - Criar
PUT    /api/transacoes/:id          - Atualizar
DELETE /api/transacoes/:id          - Deletar
GET    /api/transacoes/resumo       - Resumo do mês
```

## 🔗 Integração N8N

### URL Interna (recomendado)
```
http://financa-backend:3000/api
```

### Exemplos de Workflows

1. **Importar Excel** - Ler arquivo e criar transações
2. **Sincronizar Google Sheets** - Atualizar planilha
3. **Notificação de Orçamento** - Alertar quando excedido
4. **Relatório Mensal** - Enviar por email
5. **Backup Automático** - Fazer backup do banco

Ver: **N8N_INTEGRACAO.md**

## 🛠️ Comandos Úteis

```bash
# Ver status
docker-compose ps

# Ver logs
docker-compose logs -f

# Parar
docker-compose stop

# Reiniciar
docker-compose restart

# Remover tudo
docker-compose down -v

# Acessar MySQL
docker-compose exec mysql-financa mysql -u financa_user -p financa_pessoal

# Acessar Backend
docker-compose exec backend-financa sh
```

## 🔐 Segurança

Antes de produção:

1. Alterar senhas padrão
2. Implementar autenticação JWT
3. Configurar HTTPS/SSL
4. Usar Nginx como reverse proxy
5. Configurar firewall

## 📁 Estrutura

```
/root/financa-pessoal-docker/
├── docker-compose.yml              # Orquestra containers
├── init-db.sql                     # Script do banco
├── deploy-servidor.sh              # Script de deploy
│
├── backend/                        # API Node.js
│   ├── Dockerfile
│   ├── package.json
│   └── src/
│       ├── server.js
│       ├── config/
│       ├── models/
│       ├── controllers/
│       └── routes/
│
└── frontend/                       # Interface React
    ├── Dockerfile
    ├── package.json
    └── vite.config.js
```

## 🚀 Próximos Passos

1. ✅ Instalar e verificar
2. ⏭ Testar endpoints
3. ⏭ Criar workflows N8N
4. ⏭ Desenvolver frontend
5. ⏭ Deploy em produção

## 🐛 Troubleshooting

### Erro: "Port already in use"

```bash
lsof -i :3000
kill -9 <PID>
```

### Erro: "MySQL connection refused"

```bash
docker-compose restart mysql-financa
sleep 10
```

### Erro: "N8N não consegue acessar API"

```bash
# Verificar containers
docker-compose ps

# Testar conexão
docker-compose exec backend-financa curl http://localhost:3000/health
```

## 📞 Suporte

- [Docker Docs](https://docs.docker.com/)
- [Express Docs](https://expressjs.com/)
- [React Docs](https://react.dev/)
- [N8N Docs](https://docs.n8n.io/)

## 📄 Licença

MIT

---

**Pronto para começar!** 🎉

```bash
cd /root/financa-pessoal-docker
./deploy-servidor.sh
```
