# 🔗 Integração com N8N - Controle Financeiro

Guia completo para integrar a aplicação de controle financeiro com N8N.

## 📋 Visão Geral

Com N8N você pode automatizar:

- ✅ Importar transações de Excel
- ✅ Sincronizar com Google Sheets
- ✅ Enviar notificações de orçamento
- ✅ Gerar relatórios automáticos
- ✅ Agendar tarefas periódicas

## 🔌 URLs de Acesso

### Do N8N para a API

**URL Interna (recomendado):**
```
http://financa-backend:3000/api
```

**URL Externa (se necessário):**
```
http://localhost:3000/api
```

## 📡 Endpoints Disponíveis

### Categorias
```
GET    /categorias              - Listar todas
GET    /categorias/:id          - Obter uma
POST   /categorias              - Criar
PUT    /categorias/:id          - Atualizar
DELETE /categorias/:id          - Deletar
```

### Transações
```
GET    /transacoes              - Listar todas
GET    /transacoes/:id          - Obter uma
POST   /transacoes              - Criar
PUT    /transacoes/:id          - Atualizar
DELETE /transacoes/:id          - Deletar
GET    /transacoes/resumo       - Resumo do mês
```

## 🚀 Exemplos de Workflows

### Workflow 1: Importar Transações de Excel

**Objetivo:** Ler arquivo Excel e criar transações automaticamente

**Passos:**

1. **Trigger: File Trigger**
   - Pasta: `/uploads` (ou outra)
   - Tipo: Excel (.xlsx)

2. **Node: Read Spreadsheet**
   - Ler arquivo Excel

3. **Node: Loop Over Items**
   - Iterar sobre cada linha

4. **Node: HTTP Request**
   ```
   Method: POST
   URL: http://financa-backend:3000/api/transacoes
   Headers:
     Content-Type: application/json
   Body:
     {
       "categoria_id": {{$node["Loop"].json.categoria_id}},
       "descricao": {{$node["Loop"].json.descricao}},
       "valor": {{$node["Loop"].json.valor}},
       "tipo": {{$node["Loop"].json.tipo}},
       "data_transacao": {{$node["Loop"].json.data}},
       "status": "pago"
     }
   ```

5. **Node: Notification**
   - Notificar sucesso/erro

### Workflow 2: Sincronizar com Google Sheets

**Objetivo:** Atualizar planilha Google Sheets com transações

**Passos:**

1. **Trigger: Cron**
   ```
   0 0 * * *  (Diariamente à meia-noite)
   ```

2. **Node: HTTP Request**
   ```
   Method: GET
   URL: http://financa-backend:3000/api/transacoes
   Query:
     data_inicio: 2025-01-01
     data_fim: 2025-01-31
   ```

3. **Node: Google Sheets**
   - Atualizar planilha com dados

4. **Node: Notification**
   - Notificar conclusão

### Workflow 3: Notificação de Orçamento Excedido

**Objetivo:** Alertar quando orçamento é excedido

**Passos:**

1. **Trigger: Cron**
   ```
   0 9 * * *  (Diariamente às 9h)
   ```

2. **Node: HTTP Request**
   ```
   Method: GET
   URL: http://financa-backend:3000/api/transacoes/resumo
   Query:
     mes: {{$now.month()}}
     ano: {{$now.year()}}
   ```

3. **Node: Function**
   ```javascript
   // Calcular total de despesas
   const despesas = $node["HTTP Request"].json.find(x => x.tipo === 'despesa');
   const total = despesas ? despesas.total : 0;
   
   return [{
     total: total,
     limite: 5000,
     excedido: total > 5000
   }];
   ```

4. **Node: IF**
   - Condição: `{{$node["Function"].json.excedido}} === true`

5. **Node: Email/Slack**
   ```
   Assunto: ⚠️ Orçamento Excedido!
   
   Você excedeu o orçamento de janeiro:
   Limite: R$ 5.000,00
   Gasto: R$ {{$node["Function"].json.total}}
   Excesso: R$ {{$node["Function"].json.total - $node["Function"].json.limite}}
   ```

### Workflow 4: Relatório Mensal por Email

**Objetivo:** Enviar relatório financeiro mensal

**Passos:**

1. **Trigger: Cron**
   ```
   0 0 1 * *  (Primeiro dia do mês às meia-noite)
   ```

2. **Node: HTTP Request - Receitas**
   ```
   GET http://financa-backend:3000/api/transacoes?tipo=receita
   ```

3. **Node: HTTP Request - Despesas**
   ```
   GET http://financa-backend:3000/api/transacoes?tipo=despesa
   ```

4. **Node: Function - Calcular Totais**
   ```javascript
   const receitas = $node["HTTP Request - Receitas"].json;
   const despesas = $node["HTTP Request - Despesas"].json;
   
   const totalReceitas = receitas.reduce((sum, t) => sum + t.valor, 0);
   const totalDespesas = despesas.reduce((sum, t) => sum + t.valor, 0);
   const saldo = totalReceitas - totalDespesas;
   
   return [{
     receitas: totalReceitas,
     despesas: totalDespesas,
     saldo: saldo
   }];
   ```

5. **Node: Email**
   ```
   Assunto: 📊 Relatório Financeiro - {{$now.format('MMMM/YYYY')}}
   
   Olá,
   
   Aqui está seu relatório financeiro de {{$now.format('MMMM')}}/{{$now.format('YYYY')}}:
   
   RECEITAS: R$ {{$node["Function"].json.receitas}}
   DESPESAS: R$ {{$node["Function"].json.despesas}}
   SALDO:    R$ {{$node["Function"].json.saldo}}
   
   Atenciosamente,
   Sistema de Controle Financeiro
   ```

### Workflow 5: Criar Backup do Banco de Dados

**Objetivo:** Fazer backup automático do banco de dados

**Passos:**

1. **Trigger: Cron**
   ```
   0 2 * * *  (Diariamente às 2h)
   ```

2. **Node: SSH**
   ```
   Host: seu_servidor
   Command: docker-compose -f /root/financa-pessoal-docker/docker-compose.yml exec -T mysql-financa mysqldump -u financa_user -pfinanca_password_123 financa_pessoal > /root/backups/financa_$(date +%Y%m%d_%H%M%S).sql
   ```

3. **Node: Notification**
   - Notificar conclusão

## 🔐 Autenticação (Opcional)

Se implementar JWT no backend:

**No N8N, adicionar header:**
```
Authorization: Bearer {{$env.FINANCA_API_TOKEN}}
```

**Configurar variável de ambiente no N8N:**
```
FINANCA_API_TOKEN=seu_token_aqui
```

## 📝 Exemplo Prático: Importar Excel

### Arquivo Excel Esperado

| Data | Categoria | Descrição | Valor | Tipo |
|------|-----------|-----------|-------|------|
| 2025-01-28 | 1 | Salário | 3000 | receita |
| 2025-01-28 | 5 | Supermercado | 250 | despesa |
| 2025-01-29 | 6 | Uber | 50 | despesa |

### Workflow N8N

1. **File Trigger** → Aguarda arquivo Excel
2. **Read Spreadsheet** → Lê dados
3. **Loop** → Processa cada linha
4. **HTTP Request POST** → Cria transação
5. **Email** → Notifica resultado

## 🛠️ Troubleshooting

### Erro: "Cannot reach http://financa-backend:3000"

```
Solução:
1. Verificar se container está rodando: docker-compose ps
2. Verificar se está na rede n8n_network
3. Usar URL http://financa-backend:3000 (interna)
```

### Erro: "Invalid JSON"

```
Solução:
1. Verificar formato do JSON
2. Usar JSON Editor no N8N
3. Testar com curl primeiro
```

### Erro: "Category not found"

```
Solução:
1. Verificar categoria_id existe
2. Listar categorias: GET /categorias
3. Usar ID correto
```

### N8N não consegue conectar

```
Solução:
1. Verificar rede: docker network ls
2. Verificar containers: docker ps
3. Testar: docker-compose exec backend-financa curl http://localhost:3000/health
```

## 📊 Monitoramento

### Ver Logs do Backend

```bash
docker-compose logs -f backend-financa
```

### Ver Logs do N8N

```bash
docker logs -f n8n
```

### Testar Conexão

```bash
# Do servidor
curl http://localhost:3000/api/categorias

# Do N8N container
docker-compose exec backend-financa curl http://localhost:3000/health
```

## 🔄 Webhooks (Avançado)

Se quiser que N8N receba notificações da API:

### No Backend (adicionar)

```javascript
// Quando uma transação é criada
const n8nWebhook = process.env.N8N_WEBHOOK_URL;
if (n8nWebhook) {
  axios.post(n8nWebhook, {
    evento: 'transacao_criada',
    dados: transacao
  });
}
```

### No N8N

1. **Webhook Trigger**
   - Copiar URL do webhook
   - Adicionar ao backend como `N8N_WEBHOOK_URL`

2. **Processar evento**
   - Fazer ações baseadas no evento

## 📚 Recursos Adicionais

- [Documentação N8N](https://docs.n8n.io/)
- [HTTP Request Node](https://docs.n8n.io/nodes/n8n-nodes-base.http/)
- [Google Sheets Node](https://docs.n8n.io/nodes/n8n-nodes-base.googleSheets/)
- [Cron Node](https://docs.n8n.io/nodes/n8n-nodes-base.cron/)
- [Email Node](https://docs.n8n.io/nodes/n8n-nodes-base.emailSend/)

## 🚀 Próximos Passos

1. ✅ Entender endpoints da API
2. ⏭ Criar primeiro workflow simples
3. ⏭ Testar com dados reais
4. ⏭ Criar workflows mais complexos
5. ⏭ Agendar execuções

---

**Pronto para automatizar!** 🎉

Comece com um workflow simples e vá evoluindo!
