#!/bin/bash

# Script de Deploy - Controle Financeiro Pessoal
# Para servidor com N8N já instalado

set -e

echo "================================"
echo "🚀 Deploy - Controle Financeiro"
echo "================================"
echo ""

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Função para imprimir mensagens
info() {
    echo -e "${GREEN}✓${NC} $1"
}

warn() {
    echo -e "${YELLOW}⚠${NC} $1"
}

error() {
    echo -e "${RED}✗${NC} $1"
    exit 1
}

success() {
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${GREEN}$1${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
}

# Verificar se Docker está instalado
echo "Verificando pré-requisitos..."
if ! command -v docker &> /dev/null; then
    error "Docker não está instalado"
fi
info "Docker encontrado: $(docker --version)"

if ! command -v docker-compose &> /dev/null; then
    error "Docker Compose não está instalado"
fi
info "Docker Compose encontrado: $(docker-compose --version)"

# Verificar se N8N está rodando
echo ""
echo "Verificando N8N..."
if docker ps | grep -q n8n; then
    info "N8N está rodando"
else
    warn "N8N não está rodando, mas continuando..."
fi

# Verificar rede N8N
echo ""
echo "Verificando rede Docker..."
if docker network ls | grep -q n8n_network; then
    info "Rede n8n_network encontrada"
else
    warn "Rede n8n_network não encontrada, criando..."
    docker network create n8n_network || warn "Rede pode já existir"
fi

echo ""
echo "Verificando containers existentes..."
docker-compose ps 2>/dev/null || true

echo ""
read -p "Deseja continuar com o deploy? (s/n) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Ss]$ ]]; then
    warn "Deploy cancelado"
    exit 1
fi

echo ""
echo "================================"
echo "📦 Iniciando Containers"
echo "================================"
echo ""

# Parar containers existentes
if docker-compose ps | grep -q "Up"; then
    warn "Parando containers existentes..."
    docker-compose down
fi

# Iniciar containers
info "Iniciando containers..."
docker-compose up -d

# Aguardar MySQL estar pronto
echo ""
echo "Aguardando MySQL inicializar..."
for i in {1..30}; do
    if docker-compose exec -T mysql-financa mysqladmin ping -h localhost &> /dev/null; then
        info "MySQL está pronto!"
        break
    fi
    echo -n "."
    sleep 1
done

echo ""
echo "Aguardando Backend inicializar..."
sleep 5

echo ""
echo "================================"
echo "✅ Status dos Containers"
echo "================================"
echo ""
docker-compose ps

echo ""
success "🎉 Deploy Concluído com Sucesso!"

echo ""
echo "================================"
echo "🌐 Acessar a Aplicação"
echo "================================"
echo ""
echo "Frontend:  http://localhost:5173"
echo "API:       http://localhost:3000"
echo "Health:    http://localhost:3000/health"
echo ""

echo "================================"
echo "🔗 Integração com N8N"
echo "================================"
echo ""
echo "URL Interna (do N8N):  http://financa-backend:3000/api"
echo "URL Externa:           http://localhost:3000/api"
echo ""

echo "================================"
echo "📊 Banco de Dados"
echo "================================"
echo ""
echo "Host:     localhost"
echo "Porta:    3307"
echo "Usuário:  financa_user"
echo "Senha:    financa_password_123"
echo "Database: financa_pessoal"
echo ""

echo "================================"
echo "🛠️ Comandos Úteis"
echo "================================"
echo ""
echo "Ver logs:              docker-compose logs -f"
echo "Parar:                 docker-compose stop"
echo "Reiniciar:             docker-compose restart"
echo "Remover tudo:          docker-compose down -v"
echo "Acessar MySQL:         docker-compose exec mysql-financa mysql -u financa_user -p financa_pessoal"
echo "Acessar Backend:       docker-compose exec backend-financa sh"
echo ""

echo "================================"
echo "📚 Documentação"
echo "================================"
echo ""
echo "Guia de Instalação:    cat INSTALACAO_SERVIDOR.md"
echo "Integração N8N:        cat N8N_INTEGRACAO.md"
echo "README:                cat README.md"
echo ""

info "Deploy concluído! 🚀"
