require('dotenv').config();
require('express-async-errors');

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');

// Importar rotas
const categoriasRoutes = require('./routes/categorias');
const transacoesRoutes = require('./routes/transacoes');
const orcamentosRoutes = require('./routes/orcamentos');
const contasRoutes = require('./routes/contas');
const transferenciasRoutes = require('./routes/transferencias');
const metasRoutes = require('./routes/metas');

const app = express();

// Middleware de segurança
app.use(helmet());

// Middleware de CORS
app.use(cors({
  origin: process.env.CORS_ORIGIN || 'http://localhost:5173',
  credentials: true,
}));

// Middleware de logging
app.use(morgan('combined'));

// Middleware de parsing
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Rotas
app.use('/api/categorias', categoriasRoutes);
app.use('/api/transacoes', transacoesRoutes);
app.use('/api/orcamentos', orcamentosRoutes);
app.use('/api/contas', contasRoutes);
app.use('/api/transferencias', transferenciasRoutes);
app.use('/api/metas', metasRoutes);

// Rota de saúde
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'OK', timestamp: new Date().toISOString() });
});

// Rota raiz
app.get('/', (req, res) => {
  res.json({
    message: 'API de Controle Financeiro Pessoal',
    version: '1.0.0',
    endpoints: {
      categorias: '/api/categorias',
      transacoes: '/api/transacoes',
      orcamentos: '/api/orcamentos',
      contas: '/api/contas',
      transferencias: '/api/transferencias',
      metas: '/api/metas',
    },
  });
});

// Middleware de tratamento de erros
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(err.status || 500).json({
    error: {
      message: err.message || 'Erro interno do servidor',
      status: err.status || 500,
    },
  });
});

// Iniciar servidor
const PORT = process.env.API_PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Servidor rodando na porta ${PORT}`);
  console.log(`📊 API de Controle Financeiro Pessoal`);
  console.log(`🔗 http://localhost:${PORT}`);
});
