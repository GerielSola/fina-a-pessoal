const Transacao = require('../models/Transacao');

class TransacoesController {
  static async getAll(req, res) {
    try {
      const filtros = {
        categoria_id: req.query.categoria_id,
        tipo: req.query.tipo,
        status: req.query.status,
        data_inicio: req.query.data_inicio,
        data_fim: req.query.data_fim,
      };

      const transacoes = await Transacao.getAll(filtros);
      res.json(transacoes);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async getById(req, res) {
    try {
      const { id } = req.params;
      const transacao = await Transacao.getById(id);

      if (!transacao) {
        return res.status(404).json({ error: 'Transação não encontrada' });
      }

      res.json(transacao);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async create(req, res) {
    try {
      const {
        categoria_id,
        descricao,
        valor,
        tipo,
        data_transacao,
        data_pagamento,
        status,
        notas,
      } = req.body;

      // Validações
      if (!categoria_id || !descricao || !valor || !tipo || !data_transacao) {
        return res.status(400).json({
          error: 'categoria_id, descricao, valor, tipo e data_transacao são obrigatórios',
        });
      }

      if (!['receita', 'despesa'].includes(tipo)) {
        return res.status(400).json({ error: 'Tipo deve ser "receita" ou "despesa"' });
      }

      if (!['pendente', 'pago', 'cancelado'].includes(status || 'pendente')) {
        return res.status(400).json({
          error: 'Status deve ser "pendente", "pago" ou "cancelado"',
        });
      }

      const id = await Transacao.create({
        categoria_id,
        descricao,
        valor,
        tipo,
        data_transacao,
        data_pagamento,
        status: status || 'pendente',
        notas,
      });

      res.status(201).json({
        id,
        categoria_id,
        descricao,
        valor,
        tipo,
        data_transacao,
        data_pagamento,
        status: status || 'pendente',
        notas,
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async update(req, res) {
    try {
      const { id } = req.params;
      const {
        categoria_id,
        descricao,
        valor,
        tipo,
        data_transacao,
        data_pagamento,
        status,
        notas,
      } = req.body;

      const updated = await Transacao.update(id, {
        categoria_id,
        descricao,
        valor,
        tipo,
        data_transacao,
        data_pagamento,
        status,
        notas,
      });

      if (!updated) {
        return res.status(404).json({ error: 'Transação não encontrada' });
      }

      res.json({ message: 'Transação atualizada com sucesso' });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async delete(req, res) {
    try {
      const { id } = req.params;
      const deleted = await Transacao.delete(id);

      if (!deleted) {
        return res.status(404).json({ error: 'Transação não encontrada' });
      }

      res.json({ message: 'Transação deletada com sucesso' });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async getResumo(req, res) {
    try {
      const { mes, ano } = req.query;

      if (!mes || !ano) {
        return res.status(400).json({ error: 'Mês e ano são obrigatórios' });
      }

      const resumo = await Transacao.getResumo(mes, ano);
      res.json(resumo);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }
}

module.exports = TransacoesController;
