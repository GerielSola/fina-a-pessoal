const Categoria = require('../models/Categoria');

class CategoriasController {
  static async getAll(req, res) {
    try {
      const { tipo } = req.query;
      const categorias = await Categoria.getAll(tipo);
      res.json(categorias);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async getById(req, res) {
    try {
      const { id } = req.params;
      const categoria = await Categoria.getById(id);

      if (!categoria) {
        return res.status(404).json({ error: 'Categoria não encontrada' });
      }

      res.json(categoria);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async create(req, res) {
    try {
      const { nome, tipo, descricao } = req.body;

      if (!nome || !tipo) {
        return res.status(400).json({ error: 'Nome e tipo são obrigatórios' });
      }

      if (!['receita', 'despesa'].includes(tipo)) {
        return res.status(400).json({ error: 'Tipo deve ser "receita" ou "despesa"' });
      }

      const id = await Categoria.create(nome, tipo, descricao);
      res.status(201).json({ id, nome, tipo, descricao });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async update(req, res) {
    try {
      const { id } = req.params;
      const { nome, tipo, descricao } = req.body;

      if (!nome || !tipo) {
        return res.status(400).json({ error: 'Nome e tipo são obrigatórios' });
      }

      const updated = await Categoria.update(id, nome, tipo, descricao);

      if (!updated) {
        return res.status(404).json({ error: 'Categoria não encontrada' });
      }

      res.json({ message: 'Categoria atualizada com sucesso' });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async delete(req, res) {
    try {
      const { id } = req.params;
      const deleted = await Categoria.delete(id);

      if (!deleted) {
        return res.status(404).json({ error: 'Categoria não encontrada' });
      }

      res.json({ message: 'Categoria deletada com sucesso' });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }
}

module.exports = CategoriasController;
