const express = require('express');

const router = express.Router();

// Rotas para orçamentos
router.get('/', (req, res) => {
  res.json({ message: 'Listar orçamentos' });
});

router.post('/', (req, res) => {
  res.json({ message: 'Criar orçamento' });
});

module.exports = router;
