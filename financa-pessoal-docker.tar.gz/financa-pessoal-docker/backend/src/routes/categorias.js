const express = require('express');
const CategoriasController = require('../controllers/categoriasController');

const router = express.Router();

router.get('/', CategoriasController.getAll);
router.get('/:id', CategoriasController.getById);
router.post('/', CategoriasController.create);
router.put('/:id', CategoriasController.update);
router.delete('/:id', CategoriasController.delete);

module.exports = router;
