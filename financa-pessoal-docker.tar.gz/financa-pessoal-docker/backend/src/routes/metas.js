const express = require('express');

const router = express.Router();

// Rotas para metas
router.get('/', (req, res) => {
  res.json({ message: 'Listar metas' });
});

router.post('/', (req, res) => {
  res.json({ message: 'Criar meta' });
});

module.exports = router;
