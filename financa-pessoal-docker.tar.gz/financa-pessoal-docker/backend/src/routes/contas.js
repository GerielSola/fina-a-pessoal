const express = require('express');

const router = express.Router();

// Rotas para contas
router.get('/', (req, res) => {
  res.json({ message: 'Listar contas' });
});

router.post('/', (req, res) => {
  res.json({ message: 'Criar conta' });
});

module.exports = router;
