const express = require('express');
const TransacoesController = require('../controllers/transacoesController');

const router = express.Router();

router.get('/', TransacoesController.getAll);
router.get('/resumo', TransacoesController.getResumo);
router.get('/:id', TransacoesController.getById);
router.post('/', TransacoesController.create);
router.put('/:id', TransacoesController.update);
router.delete('/:id', TransacoesController.delete);

module.exports = router;
