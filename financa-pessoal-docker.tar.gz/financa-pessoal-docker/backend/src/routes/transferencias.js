const express = require('express');

const router = express.Router();

// Rotas para transferências
router.get('/', (req, res) => {
  res.json({ message: 'Listar transferências' });
});

router.post('/', (req, res) => {
  res.json({ message: 'Criar transferência' });
});

module.exports = router;
