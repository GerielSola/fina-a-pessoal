const pool = require('../config/database');

class Transacao {
  static async getAll(filtros = {}) {
    try {
      let query = 'SELECT * FROM transacoes WHERE 1=1';
      const params = [];

      if (filtros.categoria_id) {
        query += ' AND categoria_id = ?';
        params.push(filtros.categoria_id);
      }

      if (filtros.tipo) {
        query += ' AND tipo = ?';
        params.push(filtros.tipo);
      }

      if (filtros.status) {
        query += ' AND status = ?';
        params.push(filtros.status);
      }

      if (filtros.data_inicio && filtros.data_fim) {
        query += ' AND data_transacao BETWEEN ? AND ?';
        params.push(filtros.data_inicio, filtros.data_fim);
      }

      query += ' ORDER BY data_transacao DESC, criada_em DESC';

      const [rows] = await pool.query(query, params);
      return rows;
    } catch (error) {
      throw new Error(`Erro ao buscar transações: ${error.message}`);
    }
  }

  static async getById(id) {
    try {
      const [rows] = await pool.query('SELECT * FROM transacoes WHERE id = ?', [id]);
      return rows[0];
    } catch (error) {
      throw new Error(`Erro ao buscar transação: ${error.message}`);
    }
  }

  static async create(transacao) {
    try {
      const {
        categoria_id,
        descricao,
        valor,
        tipo,
        data_transacao,
        data_pagamento,
        status,
        notas,
      } = transacao;

      const [result] = await pool.query(
        `INSERT INTO transacoes 
         (categoria_id, descricao, valor, tipo, data_transacao, data_pagamento, status, notas) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [categoria_id, descricao, valor, tipo, data_transacao, data_pagamento, status, notas]
      );

      return result.insertId;
    } catch (error) {
      throw new Error(`Erro ao criar transação: ${error.message}`);
    }
  }

  static async update(id, transacao) {
    try {
      const {
        categoria_id,
        descricao,
        valor,
        tipo,
        data_transacao,
        data_pagamento,
        status,
        notas,
      } = transacao;

      const [result] = await pool.query(
        `UPDATE transacoes 
         SET categoria_id = ?, descricao = ?, valor = ?, tipo = ?, 
             data_transacao = ?, data_pagamento = ?, status = ?, notas = ? 
         WHERE id = ?`,
        [categoria_id, descricao, valor, tipo, data_transacao, data_pagamento, status, notas, id]
      );

      return result.affectedRows > 0;
    } catch (error) {
      throw new Error(`Erro ao atualizar transação: ${error.message}`);
    }
  }

  static async delete(id) {
    try {
      const [result] = await pool.query('DELETE FROM transacoes WHERE id = ?', [id]);
      return result.affectedRows > 0;
    } catch (error) {
      throw new Error(`Erro ao deletar transação: ${error.message}`);
    }
  }

  static async getResumo(mes, ano) {
    try {
      const query = `
        SELECT 
          tipo,
          SUM(valor) as total,
          COUNT(*) as quantidade
        FROM transacoes
        WHERE MONTH(data_transacao) = ? AND YEAR(data_transacao) = ?
        GROUP BY tipo
      `;

      const [rows] = await pool.query(query, [mes, ano]);
      return rows;
    } catch (error) {
      throw new Error(`Erro ao buscar resumo: ${error.message}`);
    }
  }
}

module.exports = Transacao;
