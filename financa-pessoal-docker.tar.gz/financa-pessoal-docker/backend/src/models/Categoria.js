const pool = require('../config/database');

class Categoria {
  static async getAll(tipo = null) {
    try {
      let query = 'SELECT * FROM categorias WHERE ativa = TRUE';
      const params = [];

      if (tipo) {
        query += ' AND tipo = ?';
        params.push(tipo);
      }

      query += ' ORDER BY nome ASC';

      const [rows] = await pool.query(query, params);
      return rows;
    } catch (error) {
      throw new Error(`Erro ao buscar categorias: ${error.message}`);
    }
  }

  static async getById(id) {
    try {
      const [rows] = await pool.query('SELECT * FROM categorias WHERE id = ?', [id]);
      return rows[0];
    } catch (error) {
      throw new Error(`Erro ao buscar categoria: ${error.message}`);
    }
  }

  static async create(nome, tipo, descricao = null) {
    try {
      const [result] = await pool.query(
        'INSERT INTO categorias (nome, tipo, descricao) VALUES (?, ?, ?)',
        [nome, tipo, descricao]
      );
      return result.insertId;
    } catch (error) {
      throw new Error(`Erro ao criar categoria: ${error.message}`);
    }
  }

  static async update(id, nome, tipo, descricao) {
    try {
      const [result] = await pool.query(
        'UPDATE categorias SET nome = ?, tipo = ?, descricao = ? WHERE id = ?',
        [nome, tipo, descricao, id]
      );
      return result.affectedRows > 0;
    } catch (error) {
      throw new Error(`Erro ao atualizar categoria: ${error.message}`);
    }
  }

  static async delete(id) {
    try {
      const [result] = await pool.query(
        'UPDATE categorias SET ativa = FALSE WHERE id = ?',
        [id]
      );
      return result.affectedRows > 0;
    } catch (error) {
      throw new Error(`Erro ao deletar categoria: ${error.message}`);
    }
  }
}

module.exports = Categoria;
