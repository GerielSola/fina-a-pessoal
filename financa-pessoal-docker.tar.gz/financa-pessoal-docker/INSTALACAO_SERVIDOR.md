# 📦 Instalação - Controle Financeiro Integrado com N8N

Guia para instalar a aplicação de controle financeiro no servidor Linux onde N8N já está rodando.

## 🎯 Visão Geral

Esta aplicação está configurada para:
- ✅ Rodar em `/root/financa-pessoal-docker`
- ✅ Compartilhar a rede Docker do N8N
- ✅ Usar MySQL em porta 3307 (para não conflitar)
- ✅ Backend em porta 3000
- ✅ Frontend em porta 5173

## 📋 Pré-requisitos

- ✅ Docker Compose instalado
- ✅ N8N já rodando (com rede Docker `n8n_network`)
- ✅ Portas 3000, 3307, 5173 disponíveis

## 🚀 Instalação Rápida (4 passos)

### Passo 1: Verificar N8N

```bash
# Verificar se N8N está rodando
docker ps | grep n8n

# Verificar rede do N8N
docker network ls | grep n8n
```

Você deve ver algo como:
```
n8n_network   bridge
```

### Passo 2: Navegar para o diretório

```bash
cd /root/financa-pessoal-docker
```

### Passo 3: Iniciar os containers

```bash
# Iniciar em background
docker-compose up -d

# Ou em modo interativo para ver logs
docker-compose up
```

### Passo 4: Verificar status

```bash
docker-compose ps
```

Você deve ver:
```
NAME                    STATUS              PORTS
financa-mysql           Up 2 minutes        0.0.0.0:3307->3306/tcp
financa-backend         Up 2 minutes        0.0.0.0:3000->3000/tcp
financa-frontend        Up 2 minutes        0.0.0.0:5173->5173/tcp
```

## 🌐 Acessar a Aplicação

| Serviço | URL |
|---------|-----|
| **Frontend** | http://localhost:5173 |
| **API** | http://localhost:3000 |
| **Health Check** | http://localhost:3000/health |

Se acessar remotamente, substitua `localhost` pelo IP do servidor:
- http://192.168.1.100:5173
- http://192.168.1.100:3000

## 🔗 Integração com N8N

### Acessar N8N

```bash
# Verificar porta do N8N
docker ps | grep n8n

# Geralmente em http://localhost:3333
```

### Conectar à API da Aplicação

No N8N, use a URL:
```
http://financa-backend:3000/api
```

Ou do seu computador:
```
http://localhost:3000/api
```

### Exemplo: HTTP Request no N8N

```
Method: GET
URL: http://financa-backend:3000/api/categorias
```

## 📊 Banco de Dados

### Credenciais

| Campo | Valor |
|-------|-------|
| Host | localhost |
| Porta | 3307 |
| Usuário | financa_user |
| Senha | financa_password_123 |
| Database | financa_pessoal |

### Acessar MySQL

```bash
# Via Docker
docker-compose exec mysql-financa mysql -u financa_user -p financa_pessoal

# Ou diretamente (se MySQL client instalado)
mysql -h localhost -P 3307 -u financa_user -p financa_pessoal
```

## 🛠️ Comandos Úteis

### Gerenciar Containers

```bash
# Ver status
docker-compose ps

# Ver logs
docker-compose logs -f

# Ver logs de um serviço
docker-compose logs -f backend-financa
docker-compose logs -f mysql-financa

# Parar
docker-compose stop

# Reiniciar
docker-compose restart

# Parar e remover (com dados)
docker-compose down

# Parar e remover (sem dados)
docker-compose down -v
```

### Executar Comandos

```bash
# Acessar shell do backend
docker-compose exec backend-financa sh

# Instalar pacote no backend
docker-compose exec backend-financa npm install package-name

# Executar comando no MySQL
docker-compose exec mysql-financa mysql -u financa_user -p financa_pessoal
```

## 📡 Testar a API

### Listar Categorias

```bash
curl http://localhost:3000/api/categorias
```

### Criar Transação

```bash
curl -X POST http://localhost:3000/api/transacoes \
  -H "Content-Type: application/json" \
  -d '{
    "categoria_id": 1,
    "descricao": "Salário",
    "valor": 3000,
    "tipo": "receita",
    "data_transacao": "2025-01-28",
    "status": "pago"
  }'
```

### Listar Transações

```bash
curl http://localhost:3000/api/transacoes
```

## 🔐 Segurança

### Alterar Senhas Padrão

**Editar `docker-compose.yml`:**

```bash
nano docker-compose.yml
```

Alterar:
```yaml
MYSQL_ROOT_PASSWORD: sua_senha_forte
MYSQL_PASSWORD: outra_senha_forte
```

**Editar `backend/.env`:**

```bash
nano backend/.env
```

Adicionar:
```
DB_PASSWORD=outra_senha_forte
JWT_SECRET=chave_secreta_muito_forte
```

Reiniciar:
```bash
docker-compose down
docker-compose up -d
```

## 🔄 Integração N8N - Exemplos

### Workflow 1: Importar Transações de Excel

1. **Trigger**: File Trigger (quando arquivo é enviado)
2. **Read File**: Ler arquivo Excel
3. **Loop**: Iterar sobre linhas
4. **HTTP Request**: POST para `http://financa-backend:3000/api/transacoes`

### Workflow 2: Sincronizar com Google Sheets

1. **Trigger**: Cron (diariamente)
2. **HTTP Request**: GET `http://financa-backend:3000/api/transacoes`
3. **Google Sheets**: Atualizar planilha

### Workflow 3: Notificação de Orçamento

1. **Trigger**: Cron (diariamente)
2. **HTTP Request**: GET `http://financa-backend:3000/api/transacoes/resumo`
3. **IF**: Verificar se valor > orçamento
4. **Email/Slack**: Enviar notificação

## 🐛 Troubleshooting

### Erro: "Cannot connect to network"

```bash
# Verificar se rede N8N existe
docker network ls | grep n8n

# Se não existir, criar
docker network create n8n_network
```

### Erro: "Port already in use"

```bash
# Encontrar processo usando a porta
lsof -i :3000
lsof -i :3307
lsof -i :5173

# Matar processo
kill -9 <PID>

# Ou mudar porta no docker-compose.yml
```

### Erro: "MySQL connection refused"

```bash
# Reiniciar MySQL
docker-compose restart mysql-financa

# Aguardar 10 segundos
sleep 10

# Ver logs
docker-compose logs mysql-financa
```

### Erro: "N8N não consegue acessar API"

```bash
# Verificar se backend está rodando
docker-compose ps

# Testar conexão
docker-compose exec backend-financa curl http://localhost:3000/health

# Do N8N, usar URL interna
http://financa-backend:3000/api
```

## 📚 Documentação Adicional

- `README.md` - Documentação técnica completa
- `QUICK_START.md` - Guia rápido
- `N8N_INTEGRACAO.md` - Exemplos de integração com N8N

## 🚀 Próximos Passos

1. ✅ Instalar e verificar status
2. ⏭ Testar endpoints da API
3. ⏭ Criar workflows no N8N
4. ⏭ Desenvolver interface do frontend
5. ⏭ Deploy em produção

## 📞 Suporte

Se encontrar problemas:

1. Verificar logs: `docker-compose logs`
2. Verificar status: `docker-compose ps`
3. Reiniciar: `docker-compose restart`
4. Consultar documentação oficial do Docker

---

**Pronto para começar!** 🎉

Para iniciar agora:
```bash
cd /root/financa-pessoal-docker
docker-compose up -d
docker-compose ps
```
