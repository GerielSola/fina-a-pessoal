#!/bin/bash

# Script para restaurar backup
set -e

if [ -z "$1" ]; then
  echo "Uso: $0 <arquivo_backup.sql.gz>"
  echo "Exemplo: $0 backup_20240101_120000.sql.gz"
  exit 1
fi

BACKUP_FILE="./database/backups/$1"

if [ ! -f "$BACKUP_FILE" ]; then
  echo "Arquivo não encontrado: $BACKUP_FILE"
  echo "Backups disponíveis:"
  ls -la ./database/backups/backup_*.sql.gz 2>/dev/null || echo "Nenhum backup encontrado"
  exit 1
fi

echo "========================================"
echo "Restaurando backup: $1"
echo "========================================"

read -p "Tem certeza? Isso irá sobrescrever o banco atual. (s/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Ss]$ ]]; then
  echo "Operação cancelada."
  exit 1
fi

# Carregar variáveis de ambiente
if [ -f .env ]; then
  export $(grep -v '^#' .env | xargs)
fi

echo "Restaurando banco de dados..."
gunzip -c "$BACKUP_FILE" | docker-compose exec -T mysql-financa mysql \
  -u root \
  -p"${DB_ROOT_PASSWORD}" \
  "${DB_NAME}"

if [ $? -eq 0 ]; then
  echo "✅ Backup restaurado com sucesso!"
else
  echo "❌ Erro ao restaurar backup"
  exit 1
fi

echo "========================================"
echo "Reiniciando serviços..."
docker-compose restart backend-financa
echo "✅ Restauração concluída!"
echo "========================================"
