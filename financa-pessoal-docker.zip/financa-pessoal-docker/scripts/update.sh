#!/bin/bash
set -e

echo "🔄 Iniciando atualização do projeto..."

# Fazer backup antes de atualizar
echo "💾 Fazendo backup do banco de dados..."
./scripts/backup.sh

# Parar containers
echo "🛑 Parando containers..."
docker-compose down

# Atualizar dependências do backend
echo "📦 Atualizando dependências do backend..."
docker-compose run --rm backend-financa npm install

# Atualizar dependências do frontend
echo "📦 Atualizando dependências do frontend..."
docker-compose run --rm frontend-financa npm install

# Rebuild das imagens
echo "🔨 Compilando imagens..."
docker-compose build

# Iniciar containers
echo "▶️  Iniciando containers..."
docker-compose up -d

echo "✅ Atualização concluída com sucesso!"
