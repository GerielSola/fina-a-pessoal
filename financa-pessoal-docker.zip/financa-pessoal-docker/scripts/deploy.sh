#!/bin/bash

# Script de deploy para produção
set -e

echo "========================================"
echo "Deploy do Finanças Pessoais"
echo "========================================"

# Parar serviços atuais
echo "Parando serviços..."
docker-compose down

# Atualizar imagens
echo "Atualizando imagens..."
docker-compose pull

# Rebuild e iniciar
echo "Iniciando serviços..."
docker-compose -f docker-compose.yml -f docker-compose.prod.yml up -d --build

# Verificar status
echo "Verificando status..."
sleep 10
docker-compose ps

# Health check
echo "Verificando saúde dos serviços..."
curl -f http://localhost:3000/health || echo "Backend não responde"
curl -f http://localhost || echo "Frontend não responde"

echo "========================================"
echo "✅ Deploy concluído com sucesso!"
echo "========================================"
