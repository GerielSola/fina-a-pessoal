#!/bin/bash

# Script de backup para Finanças Pessoais
set -e

echo "========================================"
echo "Iniciando backup do sistema"
echo "========================================"

# Carregar variáveis de ambiente
if [ -f .env ]; then
  export $(grep -v '^#' .env | xargs)
fi

BACKUP_DIR="./database/backups"
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="$BACKUP_DIR/backup_$DATE.sql.gz"

# Criar diretório de backup
mkdir -p "$BACKUP_DIR"

echo "Backup do banco de dados..."
docker-compose exec -T mysql-financa mysqldump \
  -u root \
  -p"${DB_ROOT_PASSWORD}" \
  --single-transaction \
  --routines \
  --triggers \
  --events \
  "${DB_NAME}" | gzip > "$BACKUP_FILE"

if [ $? -eq 0 ]; then
  SIZE=$(du -h "$BACKUP_FILE" | cut -f1)
  echo "✅ Backup concluído: $BACKUP_FILE ($SIZE)"

  # Limpar backups antigos (mantém últimos 7 dias)
  find "$BACKUP_DIR" -name "backup_*.sql.gz" -mtime +7 -delete
  echo "🗑️  Backups antigos removidos (mais de 7 dias)"

else
  echo "❌ Erro ao fazer backup"
  exit 1
fi

echo "========================================"
echo "Backup finalizado com sucesso!"
echo "========================================"
