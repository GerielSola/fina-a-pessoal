USE financas_pessoais;

-- Inserir categorias principais
INSERT INTO categorias (nome, tipo, cor, icone, ordem) VALUES
-- RECEITAS
('Receitas', 'receita', '#4CAF50', 'trending_up', 1),

-- DESPESAS
('Investimentos', 'despesa', '#2196F3', 'account_balance', 2),
('Moradia', 'despesa', '#9C27B0', 'home', 3),
('Alimentação', 'despesa', '#F44336', 'restaurant', 4),
('Transporte', 'despesa', '#3F51B5', 'directions_car', 5),
('Educação', 'despesa', '#009688', 'school', 6),
('Lazer', 'despesa', '#E91E63', 'sports_esports', 7),
('Saúde & Beleza', 'despesa', '#00BCD4', 'favorite', 8),
('Serviços Financeiros', 'despesa', '#795548', 'account_balance_wallet', 9),
('Vestuário', 'despesa', '#FF5722', 'checkroom', 10);
