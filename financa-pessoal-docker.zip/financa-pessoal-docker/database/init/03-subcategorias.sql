USE financas_pessoais;

-- Inserir subcategorias para Receitas (ID: 1)
INSERT INTO subcategorias (categoria_id, nome, ordem) VALUES
(1, 'Salário', 1),
(1, '13º salário', 2),
(1, 'Dividendos', 3),
(1, 'Férias', 4),
(1, 'SwilleR', 5),
(1, 'Resgate Investimentos', 6),
(1, 'Outras Receitas', 7),
(1, 'Renda Extra', 8),
(1, 'Recebimento de empréstimo', 9),
(1, 'Distribuição Lucro', 10);

-- Inserir subcategorias para Investimentos (ID: 2)
INSERT INTO subcategorias (categoria_id, nome, ordem) VALUES
(2, 'Fundo de Emergência', 1),
(2, 'Fundos de Investimentos', 2),
(2, 'LCI & LCA', 3),
(2, 'Poupança', 4),
(2, 'Previdência Privada', 5),
(2, 'Renda Fixa', 6),
(2, 'Renda Variável', 7),
(2, 'Tesouro Direto', 8),
(2, 'Outras Poupança & Investimento', 9);

-- Inserir subcategorias para Moradia (ID: 3)
INSERT INTO subcategorias (categoria_id, nome, ordem) VALUES
(3, 'Celular/Internet', 1),
(3, 'Consumo de água', 2),
(3, 'Energia Elétrica', 3),
(3, 'Decoração da Casa', 4),
(3, 'Gás', 5),
(3, 'Manutenção / Reforma da casa', 6),
(3, 'Serviço de Limpeza (diarista)', 7),
(3, 'Outras Moradias', 8);

-- Inserir subcategorias para Alimentação (ID: 4)
INSERT INTO subcategorias (categoria_id, nome, ordem) VALUES
(4, 'Feira / Sacolão', 1),
(4, 'Padaria', 2),
(4, 'Restaurante', 3),
(4, 'Supermercado', 4),
(4, 'Café', 5),
(4, 'Outras (água, sorvetes, etc)', 6);

-- Inserir subcategorias para Transporte (ID: 5)
INSERT INTO subcategorias (categoria_id, nome, ordem) VALUES
(5, 'Combustível', 1),
(5, 'Estacionamento', 2),
(5, 'Financiamento de Veículo', 3),
(5, 'IPVA', 4),
(5, 'Lavagem', 5),
(5, 'Licenciamento', 6),
(5, 'Manutenção', 7),
(5, 'Ônibus / Metrô', 8),
(5, 'Pedágio', 9),
(5, 'Seguro Auto', 10),
(5, 'Taxi / Uber', 11),
(5, 'Outras Transporte', 12);

-- Inserir subcategorias para Educação (ID: 6)
INSERT INTO subcategorias (categoria_id, nome, ordem) VALUES
(6, 'Material Escolar', 1),
(6, 'Positivo Geriel', 2),
(6, 'Positivo Willian', 3),
(6, 'Transporte Escolar', 4),
(6, 'Microsoft 365 personal', 5);

-- Inserir subcategorias para Lazer (ID: 7)
INSERT INTO subcategorias (categoria_id, nome, ordem) VALUES
(7, 'Bares', 1),
(7, 'Cinema / Teatro / Shows', 2),
(7, 'Clube / Parques / Casa Noturna', 3),
(7, 'Festas', 4),
(7, 'Livros / Revistas / Cd´s', 5),
(7, 'Restaurantes', 6),
(7, 'Streaming (Netflix / Amazon / Disney)', 7),
(7, 'Viagens / Férias', 8),
(7, 'Outras Lazer', 9),
(7, 'Apple', 10),
(7, 'Spotify', 11);

-- Inserir subcategorias para Saúde & Beleza (ID: 8)
INSERT INTO subcategorias (categoria_id, nome, ordem) VALUES
(8, 'Academia', 1),
(8, 'Cabeleireiro', 2),
(8, 'Higiene Pessoal', 3),
(8, 'Farmácia', 4),
(8, 'Plano de Saúde', 5),
(8, 'Outras Saúde & Beleza', 6);

-- Inserir subcategorias para Serviços Financeiros (ID: 9)
INSERT INTO subcategorias (categoria_id, nome, ordem) VALUES
(9, 'Empréstimos', 1),
(9, 'Imposto de Renda a Pagar', 2),
(9, 'Juros Cheque Especial', 3),
(9, 'Pagamento de Dívidas', 4),
(9, 'Previdência Privada', 5),
(9, 'Seguros (vida/residencial)', 6),
(9, 'Tarifas Bancárias', 7),
(9, 'Outras Serviços Financeiros', 8);

-- Inserir subcategorias para Vestuário (ID: 10)
INSERT INTO subcategorias (categoria_id, nome, ordem) VALUES
(10, 'Acessórios', 1),
(10, 'Calçados', 2),
(10, 'Roupas', 3),
(10, 'Outras Vestuário', 4);

-- Inserir formas de pagamento padrão
INSERT INTO formas_pagamento (nome, tipo, icone) VALUES
('Dinheiro', 'dinheiro', 'payments'),
('Cartão de Crédito', 'cartao_credito', 'credit_card'),
('Cartão de Débito', 'cartao_debito', 'credit_card'),
('PIX', 'pix', 'qr_code'),
('Boleto', 'boleto', 'receipt_long'),
('Transferência Bancária', 'transferencia', 'account_balance');
