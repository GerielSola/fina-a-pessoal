-- Criar banco de dados
CREATE DATABASE IF NOT EXISTS financas_pessoais
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE financas_pessoais;

-- Tabela de usuários
CREATE TABLE IF NOT EXISTS usuarios (
  id INT PRIMARY KEY AUTO_INCREMENT,
  nome VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  senha VARCHAR(255) NOT NULL,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_email (email)
);

-- Tabela de categorias
CREATE TABLE IF NOT EXISTS categorias (
  id INT PRIMARY KEY AUTO_INCREMENT,
  nome VARCHAR(100) NOT NULL,
  tipo ENUM('receita', 'despesa') NOT NULL,
  cor VARCHAR(7) DEFAULT '#4CAF50',
  icone VARCHAR(50) DEFAULT 'category',
  ordem INT DEFAULT 0,
  ativa BOOLEAN DEFAULT TRUE,
  criada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_tipo (tipo),
  INDEX idx_ordem (ordem)
);

-- Tabela de subcategorias
CREATE TABLE IF NOT EXISTS subcategorias (
  id INT PRIMARY KEY AUTO_INCREMENT,
  categoria_id INT NOT NULL,
  nome VARCHAR(100) NOT NULL,
  descricao TEXT,
  limite_mensal DECIMAL(12,2) DEFAULT NULL,
  cor VARCHAR(7) DEFAULT NULL,
  icone VARCHAR(50) DEFAULT 'label',
  ordem INT DEFAULT 0,
  ativa BOOLEAN DEFAULT TRUE,
  criada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (categoria_id) REFERENCES categorias(id) ON DELETE CASCADE,
  UNIQUE KEY unique_subcategoria (categoria_id, nome),
  INDEX idx_categoria (categoria_id)
);

-- Tabela de transações
CREATE TABLE IF NOT EXISTS transacoes (
  id INT PRIMARY KEY AUTO_INCREMENT,
  usuario_id INT NOT NULL,
  categoria_id INT NOT NULL,
  subcategoria_id INT DEFAULT NULL,
  descricao VARCHAR(255) NOT NULL,
  valor DECIMAL(12,2) NOT NULL,
  tipo ENUM('receita', 'despesa') NOT NULL,
  data_transacao DATE NOT NULL,
  data_pagamento DATE,
  forma_pagamento VARCHAR(50) DEFAULT NULL,
  notas TEXT,
  criada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
  FOREIGN KEY (categoria_id) REFERENCES categorias(id),
  FOREIGN KEY (subcategoria_id) REFERENCES subcategorias(id) ON DELETE SET NULL,
  INDEX idx_data (data_transacao),
  INDEX idx_tipo (tipo),
  INDEX idx_usuario (usuario_id)
);

-- Tabela de contas
CREATE TABLE IF NOT EXISTS contas (
  id INT PRIMARY KEY AUTO_INCREMENT,
  usuario_id INT NOT NULL,
  nome VARCHAR(100) NOT NULL,
  tipo ENUM('banco', 'cartao_credito', 'carteira', 'investimento', 'poupanca') NOT NULL,
  instituicao VARCHAR(100) DEFAULT NULL,
  saldo_inicial DECIMAL(12,2) DEFAULT 0,
  saldo_atual DECIMAL(12,2) DEFAULT 0,
  cor VARCHAR(7) DEFAULT '#1976d2',
  ativa BOOLEAN DEFAULT TRUE,
  criada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
  INDEX idx_usuario (usuario_id)
);

-- Tabela de formas de pagamento
CREATE TABLE IF NOT EXISTS formas_pagamento (
  id INT PRIMARY KEY AUTO_INCREMENT,
  nome VARCHAR(50) NOT NULL UNIQUE,
  tipo ENUM('dinheiro', 'cartao_debito', 'cartao_credito', 'pix', 'boleto', 'transferencia', 'outro') NOT NULL,
  icone VARCHAR(50) DEFAULT 'credit_card',
  ativa BOOLEAN DEFAULT TRUE,
  criada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de metas
CREATE TABLE IF NOT EXISTS metas (
  id INT PRIMARY KEY AUTO_INCREMENT,
  usuario_id INT NOT NULL,
  nome VARCHAR(100) NOT NULL,
  descricao TEXT,
  valor_objetivo DECIMAL(12,2) NOT NULL,
  valor_atual DECIMAL(12,2) DEFAULT 0,
  data_limite DATE NOT NULL,
  concluida BOOLEAN DEFAULT FALSE,
  criada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
  INDEX idx_usuario (usuario_id)
);

-- Tabela de orçamentos
CREATE TABLE IF NOT EXISTS orcamentos (
  id INT PRIMARY KEY AUTO_INCREMENT,
  usuario_id INT NOT NULL,
  categoria_id INT NOT NULL,
  subcategoria_id INT DEFAULT NULL,
  mes_ano DATE NOT NULL,
  valor_limite DECIMAL(12,2) NOT NULL,
  valor_gasto DECIMAL(12,2) DEFAULT 0,
  ativo BOOLEAN DEFAULT TRUE,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
  FOREIGN KEY (categoria_id) REFERENCES categorias(id),
  FOREIGN KEY (subcategoria_id) REFERENCES subcategorias(id) ON DELETE SET NULL,
  UNIQUE KEY unique_orcamento (usuario_id, categoria_id, subcategoria_id, mes_ano),
  INDEX idx_mes (mes_ano)
);
