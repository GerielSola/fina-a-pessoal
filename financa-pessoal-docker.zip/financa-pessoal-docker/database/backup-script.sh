#!/bin/bash
set -e

BACKUP_DIR="./backups"
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="$BACKUP_DIR/backup_$DATE.sql.gz"

mkdir -p "$BACKUP_DIR"

echo "Iniciando backup do banco de dados..."

docker-compose exec mysql-financa mysqldump \
  -u root \
  -p"${DB_ROOT_PASSWORD}" \
  --single-transaction \
  --routines \
  --triggers \
  --events \
  financas_pessoais | gzip > "$BACKUP_FILE"

if [ $? -eq 0 ]; then
  echo "Backup concluído: $BACKUP_FILE"

  # Remover backups antigos (mais de 7 dias)
  find "$BACKUP_DIR" -name "backup_*.sql.gz" -mtime +7 -delete
  echo "Backups antigos removidos (mais de 7 dias)"
else
  echo "Erro ao fazer backup!"
  exit 1
fi
