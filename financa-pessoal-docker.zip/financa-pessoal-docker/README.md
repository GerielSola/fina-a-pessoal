# 💰 Finanças Pessoais - Sistema de Controle Financeiro

Um sistema completo de controle financeiro pessoal desenvolvido com Node.js, React e MySQL, totalmente containerizado com Docker.

## 🎯 Características

- **Autenticação segura** com JWT
- **Gerenciamento de transações** (receitas e despesas)
- **Categorização** de gastos com subcategorias
- **Múltiplas contas** (banco, cartão, carteira, etc)
- **Orçamentos** mensais por categoria
- **Metas financeiras** com acompanhamento
- **Relatórios e gráficos** de gastos
- **Formas de pagamento** customizáveis
- **Backup automático** do banco de dados
- **Interface responsiva** com React e Tailwind CSS

## 🛠️ Tecnologias

### Backend
- **Node.js** 18+
- **Express.js** - Framework web
- **MySQL** 8.0 - Banco de dados
- **Sequelize** - ORM
- **JWT** - Autenticação
- **Bcrypt** - Criptografia de senhas

### Frontend
- **React** 18+
- **Vite** - Build tool
- **Tailwind CSS** - Estilização
- **Axios** - HTTP client
- **Zustand** - State management
- **Recharts** - Gráficos

### DevOps
- **Docker** - Containerização
- **Docker Compose** - Orquestração
- **Nginx** - Reverse proxy
- **PHPMyAdmin** - Gerenciamento de BD (opcional)

## 📋 Pré-requisitos

- Docker 20.10+
- Docker Compose 2.0+
- Git

## 🚀 Instalação e Execução

### 1. Clonar o repositório

```bash
git clone <seu-repositorio>
cd financa-pessoal-docker
```

### 2. Configurar variáveis de ambiente

```bash
cp .env.example .env
```

Edite o arquivo `.env` e altere as senhas e chaves secretas:

```env
# Banco de dados
DB_ROOT_PASSWORD=sua_senha_forte_aqui
DB_PASSWORD=senha_usuario_aqui

# JWT
JWT_SECRET=sua_chave_secreta_muito_forte_aqui

# URLs
CORS_ORIGIN=http://localhost:5173
VITE_API_URL=http://localhost:3000/api
```

### 3. Iniciar os containers

```bash
# Desenvolvimento
docker-compose up -d

# Produção
docker-compose -f docker-compose.yml -f docker-compose.prod.yml up -d
```

### 4. Acessar a aplicação

- **Frontend**: http://localhost:5173
- **Backend API**: http://localhost:3000
- **PHPMyAdmin**: http://localhost:8081 (perfil: admin)

## 📖 Documentação

### Estrutura de Diretórios

```
financa-pessoal-docker/
├── backend/              # API Node.js
│   ├── src/
│   │   ├── config/      # Configurações
│   │   ├── controllers/ # Controladores
│   │   ├── models/      # Modelos de dados
│   │   ├── routes/      # Rotas da API
│   │   ├── services/    # Lógica de negócio
│   │   └── server.js    # Servidor principal
│   └── Dockerfile
│
├── frontend/            # Aplicação React
│   ├── src/
│   │   ├── components/  # Componentes React
│   │   ├── pages/       # Páginas
│   │   ├── services/    # Serviços API
│   │   └── App.jsx
│   └── Dockerfile
│
├── database/            # Scripts SQL
│   ├── init/           # Scripts de inicialização
│   └── backups/        # Backups automáticos
│
├── nginx/              # Configuração Nginx
├── scripts/            # Scripts auxiliares
└── docs/              # Documentação
```

### Scripts Disponíveis

#### Deploy

```bash
./scripts/deploy.sh
```

Realiza o deploy completo da aplicação:
- Verifica arquivo `.env`
- Atualiza imagens Docker
- Compila containers
- Inicia serviços

#### Backup

```bash
./scripts/backup.sh
```

Cria backup do banco de dados:
- Gera arquivo compactado
- Remove backups antigos (>7 dias)
- Armazena em `database/backups/`

#### Restauração

```bash
./scripts/restore.sh database/backups/backup_20240101_120000.sql.gz
```

Restaura banco de dados de um backup anterior.

#### Atualização

```bash
./scripts/update.sh
```

Atualiza dependências e imagens:
- Faz backup automático
- Atualiza npm packages
- Recompila containers
- Reinicia serviços

## 🔧 Configuração Avançada

### Variáveis de Ambiente

| Variável | Padrão | Descrição |
|----------|--------|-----------|
| `NODE_ENV` | development | Ambiente (development/production) |
| `DB_ROOT_PASSWORD` | - | Senha root do MySQL |
| `DB_NAME` | financas_pessoais | Nome do banco de dados |
| `DB_USER` | financas_user | Usuário do banco |
| `DB_PASSWORD` | - | Senha do usuário |
| `DB_PORT` | 3307 | Porta MySQL |
| `API_PORT` | 3000 | Porta da API |
| `JWT_SECRET` | - | Chave secreta JWT |
| `CORS_ORIGIN` | http://localhost:5173 | Origem CORS |
| `FRONTEND_PORT` | 5173 | Porta do frontend |
| `PHPMYADMIN_PORT` | 8081 | Porta PHPMyAdmin |

### Profiles Docker Compose

#### Admin (PHPMyAdmin)

```bash
docker-compose --profile admin up -d
```

Inicia PHPMyAdmin para gerenciar o banco de dados.

### Logs

```bash
# Todos os serviços
docker-compose logs -f

# Serviço específico
docker-compose logs -f backend-financa

# Últimas 100 linhas
docker-compose logs --tail=100
```

## 🐛 Troubleshooting

### Erro: "Cannot connect to MySQL"

```bash
# Verificar se container MySQL está rodando
docker-compose ps

# Verificar logs do MySQL
docker-compose logs mysql-financa

# Reiniciar container
docker-compose restart mysql-financa
```

### Erro: "Port already in use"

Altere as portas no arquivo `.env`:

```env
DB_PORT=3308
API_PORT=3001
FRONTEND_PORT=5174
```

### Erro: "Out of memory"

Aumente os limites de memória em `docker-compose.prod.yml`:

```yaml
services:
  backend-financa:
    mem_limit: 2g  # Aumentar de 1g
```

## 📊 API Endpoints

### Autenticação
- `POST /api/auth/register` - Registrar novo usuário
- `POST /api/auth/login` - Login
- `POST /api/auth/logout` - Logout

### Categorias
- `GET /api/categorias` - Listar categorias
- `POST /api/categorias` - Criar categoria
- `PUT /api/categorias/:id` - Atualizar categoria
- `DELETE /api/categorias/:id` - Deletar categoria

### Transações
- `GET /api/transacoes` - Listar transações
- `POST /api/transacoes` - Criar transação
- `PUT /api/transacoes/:id` - Atualizar transação
- `DELETE /api/transacoes/:id` - Deletar transação

### Contas
- `GET /api/contas` - Listar contas
- `POST /api/contas` - Criar conta
- `PUT /api/contas/:id` - Atualizar conta
- `DELETE /api/contas/:id` - Deletar conta

## 📝 Licença

Este projeto está licenciado sob a MIT License - veja o arquivo [LICENSE](LICENSE) para detalhes.

## 🤝 Contribuindo

Contribuições são bem-vindas! Por favor:

1. Faça um Fork do projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

## 📧 Suporte

Para reportar bugs ou sugerir melhorias, abra uma issue no repositório.

---

**Desenvolvido com ❤️ para controle financeiro pessoal**
