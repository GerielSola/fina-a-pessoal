require('dotenv').config();

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const morgan = require('morgan');

const app = express();

// Middlewares
app.use(helmet());
app.use(compression());
app.use(morgan('dev'));
app.use(cors({
  origin: process.env.CORS_ORIGIN || 'http://localhost:5173',
  credentials: true,
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Rotas
app.get('/', (req, res) => {
  res.json({
    message: 'API de Finanças Pessoais',
    version: '1.0.0',
    endpoints: {
      health: '/health',
      docs: '/api/docs'
    }
  });
});

app.get('/health', (req, res) => {
  res.status(200).json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    service: 'financas-api'
  });
});

app.get('/api/docs', (req, res) => {
  res.json({
    message: 'Documentação da API',
    authentication: 'Bearer Token',
    endpoints: [
      { method: 'POST', path: '/api/auth/register', description: 'Registrar usuário' },
      { method: 'POST', path: '/api/auth/login', description: 'Login' },
      { method: 'GET', path: '/api/categorias', description: 'Listar categorias' },
      { method: 'POST', path: '/api/transacoes', description: 'Criar transação' }
    ]
  });
});

// Middleware de erro 404
app.use((req, res, next) => {
  res.status(404).json({
    success: false,
    error: 'Rota não encontrada'
  });
});

// Middleware de tratamento de erros
app.use((err, req, res, next) => {
  console.error(err.stack);

  const statusCode = err.status || 500;
  const message = process.env.NODE_ENV === 'production'
    ? 'Erro interno do servidor'
    : err.message;

  res.status(statusCode).json({
    success: false,
    error: {
      message: message,
      status: statusCode,
      ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
    }
  });
});

const PORT = process.env.API_PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Servidor rodando na porta ${PORT}`);
  console.log(`📊 API de Finanças Pessoais`);
  console.log(`🔗 ${process.env.CORS_ORIGIN || 'http://localhost:5173'}`);
});
