# Documentação da API

## Autenticação

Todas as rotas (exceto `/auth/*`) requerem autenticação via Bearer Token.

```
Authorization: Bearer <token_jwt>
```

## Endpoints

### Autenticação

#### POST /api/auth/register

Registrar novo usuário.

**Body:**
```json
{
  "nome": "João Silva",
  "email": "joao@email.com",
  "senha": "senha123"
}
```

#### POST /api/auth/login

Login de usuário.

**Response:**
```json
{
  "success": true,
  "data": {
    "usuario": {
      "id": 1,
      "nome": "João Silva",
      "email": "joao@email.com"
    },
    "token": "eyJhbGciOiJIUzI1NiIs..."
  }
}
```

### Categorias

#### GET /api/categorias

Listar todas as categorias.

#### POST /api/categorias

Criar nova categoria.

**Body:**
```json
{
  "nome": "Transporte",
  "tipo": "despesa",
  "cor": "#3F51B5",
  "icone": "directions_car"
}
```

### Transações

#### GET /api/transacoes

Listar transações com filtros.

**Query Parameters:**
- `mes` - Mês (1-12)
- `ano` - Ano
- `tipo` - receita/despesa
- `categoria_id` - ID da categoria

**Exemplo:**
```
GET /api/transacoes?mes=1&ano=2024&tipo=despesa
```

#### POST /api/transacoes

Criar nova transação.

**Body:**
```json
{
  "descricao": "Supermercado",
  "valor": 150.50,
  "tipo": "despesa",
  "categoria_id": 4,
  "subcategoria_id": 4,
  "data_transacao": "2024-01-15",
  "forma_pagamento": "Cartão de Débito"
}
```

#### PUT /api/transacoes/:id

Atualizar transação.

#### DELETE /api/transacoes/:id

Excluir transação.

### Relatórios

#### GET /api/relatorios/mensal

Relatório mensal por categoria.

**Query Parameters:**
- `mes` - Mês (1-12)
- `ano` - Ano

**Response:**
```json
{
  "success": true,
  "data": {
    "receitas": 5000.00,
    "despesas": 3500.00,
    "saldo": 1500.00,
    "categorias": [
      {
        "nome": "Alimentação",
        "total": 800.00,
        "porcentagem": 22.86
      }
    ]
  }
}
```

#### GET /api/relatorios/anual

Relatório anual.

**Query Parameters:**
- `ano` - Ano

### Contas

#### GET /api/contas

Listar contas do usuário.

#### POST /api/contas

Criar nova conta.

**Body:**
```json
{
  "nome": "Conta Corrente",
  "tipo": "banco",
  "instituicao": "Banco X",
  "saldo_inicial": 1000.00
}
```

## Códigos de Status

- `200` - Sucesso
- `201` - Criado com sucesso
- `400` - Requisição inválida
- `401` - Não autorizado
- `404` - Recurso não encontrado
- `500` - Erro interno do servidor

## Exemplos com cURL

### Login

```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"joao@email.com","senha":"senha123"}'
```

### Criar Transação

```bash
curl -X POST http://localhost:3000/api/transacoes \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <seu_token_jwt>" \
  -d '{"descricao":"Salário","valor":3000.00,"tipo":"receita","categoria_id":1,"data_transacao":"2024-01-05"}'
```

### Listar Transações

```bash
curl -X GET "http://localhost:3000/api/transacoes?mes=1&ano=2024" \
  -H "Authorization: Bearer <seu_token_jwt>"
```
