# Guia de Instalação

## Requisitos do Sistema

- Docker 20.10+
- Docker Compose 2.0+
- 2GB RAM mínimo
- Linux/Windows/Mac com WSL2

## Instalação Passo a Passo

### 1. Preparar Ambiente

```bash
# Extrair arquivo
unzip financa-pessoal-docker.zip
cd financa-pessoal-docker

# Configurar variáveis de ambiente
cp .env.example .env
nano .env  # Edite com suas configurações
```

### 2. Configurar .env

Edite o arquivo `.env`:

```env
# Banco de Dados (MUDE ESTAS SENHAS!)
DB_ROOT_PASSWORD=senha_forte_root_123
DB_PASSWORD=senha_usuario_123

# JWT Secret (MUDE ESTA!)
JWT_SECRET=sua_chave_secreta_muito_forte_aqui

# Portas (ajuste se necessário)
FRONTEND_PORT=5173
API_PORT=3000
DB_PORT=3307
PHPMYADMIN_PORT=8081
```

### 3. Iniciar Serviços

```bash
# Iniciar em modo desenvolvimento
docker-compose up -d

# Verificar status
docker-compose ps

# Ver logs
docker-compose logs -f backend-financa
```

### 4. Acessar Aplicação

- **Frontend:** http://localhost:5173
- **API Backend:** http://localhost:3000
- **PHPMyAdmin:** http://localhost:8081
  - Servidor: mysql-financa
  - Usuário: root
  - Senha: (DB_ROOT_PASSWORD do .env)

## Instalação em Produção

```bash
# Usar configuração de produção
docker-compose -f docker-compose.yml -f docker-compose.prod.yml up -d

# Configurar backup automático
crontab -e
# Adicionar: 0 2 * * * /caminho/para/scripts/backup.sh
```

## Solução de Problemas

### MySQL não inicia

```bash
docker-compose logs mysql-financa
# Verifique se a senha está correta no .env
```

### Portas em uso

```bash
# Ver portas ocupadas
sudo netstat -tulpn | grep LISTEN

# Altere as portas no .env
```

### Erro de permissão

```bash
# Dar permissão de execução aos scripts
chmod +x scripts/*.sh
chmod +x database/backup-script.sh
```

### Atualização

```bash
# Parar serviços
docker-compose down

# Fazer backup
./scripts/backup.sh

# Atualizar código
# (substitua os arquivos)

# Rebuild e iniciar
docker-compose up -d --build
```

## Backup e Restauração

### Backup Manual

```bash
./scripts/backup.sh
```

### Restaurar Backup

```bash
./scripts/restore.sh backup_arquivo.sql.gz
```
